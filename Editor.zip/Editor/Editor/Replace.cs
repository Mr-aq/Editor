﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Editor
{
    public partial class Replace : Form
    {
        public Replace()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnCancel_Click(object sender, EventArgs e)
        {
            //关闭此窗体
            this.Close();
        }

        /// <summary>
        /// 替换所有
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (TextFind._RTxtBox.Text.Contains(TxtBoxReplace1.Text))
                {
                    //把目标子串替换为待替换的内容
                    string str = TextFind._RTxtBox.Text.Replace(TxtBoxReplace1.Text, TxtBoxReplace2.Text);
                    //把替换后的内容放到TxtBox中
                    TextFind._RTxtBox.Text = str;
                    this.Close();
                }
                else
                {
                    //如果母串中不含有子串则显示错误信息，并且清空输入框
                    MessageBox.Show("未找到" + TxtBoxReplace1.Text);
                    TxtBoxReplace1.Clear();
                    TxtBoxReplace2.Clear();
                }
            }
            catch { }
        }
    }
}
