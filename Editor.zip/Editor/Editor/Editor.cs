﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;
using System.Threading;

/*
 *  
 *   designer:    阙祥宇
 *   Date:    2021.05.26
 *   
 */

namespace Editor
{
    public partial class Editor : Form
    {
        public Editor()
        {
            InitializeComponent();
        }

        //用静态字段模拟全局变亮保存打开的文件
        private static string _path;

        //创建一个Find窗体的变量来记录Find窗体是否被创建
        private Find _find;

        //创建一个Replace窗体的变量来记录Find窗体是否被创建
        private Replace _replace;

        //创建数组来放用户剪切、复制的内容充当剪切板的作用
        private static string[] _clipboard = new string[10];
        //用来记录剪切板的位置
        private static int i = 0;

        /// <summary>
        /// 打开对话框
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 打开ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //创建对话框，设置对话框的一些属性
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "文本文件|*.txt|所有文件|*.*";
            openFileDialog.Title = "请选择你要打开的文件";
            openFileDialog.InitialDirectory = @"C:\Users\Mr.Q\Desktop";

            //展示对话框
            openFileDialog.ShowDialog();

            //获取选中的文件路径
            string path = openFileDialog.FileName;
            //将打开的文件路径保存到静态字段中以便保存函数调用
            _path = path;
            //获取所选择文件的扩展名
            string extension = Path.GetExtension(path);
            //如果未选中文件则退出
            if (path == "")
            {
                return;
            }
            //如果是word文档则调用applicat的方法打开
            if (extension == ".docx")
            {
                try
                {
                    //调用COM库中有关Word的类的方法
                    Word.Application app = new Word.Application();
                    Word.Document doc = null;
                    object unknow = Type.Missing;
                    app.Visible = false;
                    object file = path;
                    doc = app.Documents.Open(ref file,
                        ref unknow, ref unknow, ref unknow, ref unknow,
                        ref unknow, ref unknow, ref unknow, ref unknow,
                        ref unknow, ref unknow, ref unknow, ref unknow,
                        ref unknow, ref unknow, ref unknow);

                    //读取整篇内容将内容保存到RTxtBox中
                    string Content = doc.Content.Text;
                    RTxtBox.Text = Content;

                    //先关闭打开的文档
                    Object saveChanges = Word.WdSaveOptions.wdSaveChanges;
                    Object originalFormat = Type.Missing;
                    Object routeDocument = Type.Missing;
                    app.Documents.Close(ref saveChanges, ref originalFormat, ref routeDocument);

                    //若已经没有文档存在，则关闭应用程序
                    if (app.Documents.Count == 0)
                    {
                        app.Quit(Type.Missing, Type.Missing, Type.Missing);
                    }
                }
                catch { }
            }
            else
            {
                try
                {
                    //读取文件之前先清空之前的文件
                    RTxtBox.Clear();
                    //读取文件内容并输出到RTxtBox中
                    using (FileStream fread = new FileStream(path, FileMode.Open, FileAccess.Read))
                    {
                        int r = 1;
                        //当读取到的字节数不为0时继续读取
                        while (r != 0)
                        {
                            byte[] buffer = new byte[1024 * 1024 * 1];
                            r = fread.Read(buffer, 0, buffer.Length);   //实际读取的字节数
                            RTxtBox.AppendText(Encoding.UTF8.GetString(buffer, 0, r));   //将读取的字节数转化为字符串输出
                        }
                    }
                }
                catch { }
            }
        }

        /// <summary>
        /// 保存对当前文件的编辑
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /*
             * 先判断RTxtBox中的内容是否为空
             * 不为空则判断是否选则了文件路径
             * 如果都为空则退出不执行此方法
            */
            if (RTxtBox.Text == "")
            {
                if (_path == null || _path == "")
                {
                    return;
                }
            }
            else    //否则执行此方法
            {
                if (_path != null && _path != "")
                {
                    //把内容写入文件
                    using (FileStream fwrite = new FileStream(_path, FileMode.Create, FileAccess.Write))
                    {
                        byte[] buffer = Encoding.UTF8.GetBytes(RTxtBox.Text);
                        fwrite.Write(buffer, 0, buffer.Length); //读取当前的文档保存至原来的文件中
                    }
                }
                else
                {
                    //打开另存为对话框并设置一些属性
                    SaveFileDialog saveFileDialog = new SaveFileDialog();
                    saveFileDialog.Filter = "文本文件|*.txt|所有文件|*.*";
                    saveFileDialog.Title = "另存为";
                    saveFileDialog.InitialDirectory = @"Desktop";

                    //展示对话框
                    saveFileDialog.ShowDialog();

                    try
                    {
                        //获取保存新文件的文件名
                        string path = saveFileDialog.FileName;
                        if (path == "")
                        {
                            return;
                        }

                        //把内容写入文件
                        using (FileStream fwrite = new FileStream(path, FileMode.Create, FileAccess.Write))
                        {
                            byte[] buffer = Encoding.UTF8.GetBytes(RTxtBox.Text);
                            fwrite.Write(buffer, 0, buffer.Length); //读取当前的文档保存至新创建的文件中
                        }
                    }
                    catch { }

                }
            }
        }

        /// <summary>
        /// 打开另存为对话框
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 另存为ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //打开另存为对话框并设置一些属性
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "文本文件|*.txt|所有文件|*.*";
            saveFileDialog.Title = "另存为";
            saveFileDialog.InitialDirectory = @"Desktop";

            //展示对话框
            saveFileDialog.ShowDialog();

            //获取保存新文件的文件名
            string path = saveFileDialog.FileName;
            if (path == "")
            {
                return;
            }

            //把内容写入文件
            using (FileStream fwrite = new FileStream(path, FileMode.Create, FileAccess.Write))
            {
                byte[] buffer = Encoding.UTF8.GetBytes(RTxtBox.Text);
                fwrite.Write(buffer, 0, buffer.Length); //读取当前的文档保存至新创建的文件中
            }
        }

        /// <summary>
        /// 退出编辑器
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 退出ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //退出应用
            this.Close();
        }

        /// <summary>
        /// 自动换行
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 自动换行ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /*
             * 如果自动换行为true则改成false，否则改为true
             *自动换行默认为true
            */
            if (RTxtBox.WordWrap == true)
            {
                RTxtBox.WordWrap = false;
            }
            else
            {
                RTxtBox.WordWrap = true;
            }
        }

        /// <summary>
        /// 打开字体对话框
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 字体ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog = new FontDialog();
            fontDialog.ShowDialog();    //展示对话框
            RTxtBox.SelectionFont = fontDialog.Font;    //改变字体
        }

        /// <summary>
        /// 打开颜色对话框
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 颜色ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();
            colorDialog.ShowDialog();   //展示对话框
            RTxtBox.SelectionColor = colorDialog.Color;   //改变颜色
        }

        /// <summary>
        /// 剪切
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 剪切ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //将所选中的文本放入剪切板中，并判断当前的i的值有没有超出范围
            if (i == 9)
            {
                i = 0;
            }
            _clipboard[i] = RTxtBox.SelectedText;
            i++;
            RTxtBox.SelectedText = "";
        }

        /// <summary>
        /// 复制
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 复制ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //将所选中的文本放入剪切板中,并判断当前的i的值有没有超出范围
            if (i == 9)
            {
                i = 0;
            }
            _clipboard[i] = RTxtBox.SelectedText;
            i++;
        }

        /// <summary>
        /// 粘贴
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 粘贴ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //粘贴文本
            RTxtBox.AppendText(_clipboard[i - 1]);
        }

        /// <summary>
        /// 查找
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 查找ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /*
             * 新建查找窗体
             * 判断窗体Find是否被创建过
             * 被创建的话打开原来创建的窗体
             * 没有被创建过则重新创建
            */
            if (_find == null || _find.IsDisposed)
            {
                _find = new Find();
                _find.Show();
            }
            else
            {
                _find.Show();
                _find.TopMost = true;
            }
        }
        
        
        

        /// <summary>
        /// 在窗体加载的时候初始化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Editor_Load(object sender, EventArgs e)
        {
            //把RTxtBox存进TextFind的字段中
            TextFind._RTxtBox = this.RTxtBox;
        }

        /// <summary>
        /// 替换
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 替换ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /*
             * 新建替换窗体
             * 判断窗体Replace是否被创建过
             * 被创建的话打开原来创建的窗体
             * 没有被创建过则重新创建
            */
            if (_replace == null || _replace.IsDisposed)
            {
                _replace = new Replace();
                _replace.Show();
            }
            else
            {
                _replace.Show();
                _replace.TopMost = true;
            }
        }
    }
}
