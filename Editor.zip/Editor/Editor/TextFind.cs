﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace Editor
{
    static class TextFind
    {
        //保存TxtBox以便查找的时候调用
        public static RichTextBox _RTxtBox;
    }
}
