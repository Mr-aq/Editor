﻿
namespace Editor
{
    partial class Replace
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblReplace1 = new System.Windows.Forms.Label();
            this.LblReplace2 = new System.Windows.Forms.Label();
            this.TxtBoxReplace1 = new System.Windows.Forms.TextBox();
            this.TxtBoxReplace2 = new System.Windows.Forms.TextBox();
            this.BtnCancel = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblReplace1
            // 
            this.LblReplace1.AutoSize = true;
            this.LblReplace1.Location = new System.Drawing.Point(13, 13);
            this.LblReplace1.Name = "LblReplace1";
            this.LblReplace1.Size = new System.Drawing.Size(60, 15);
            this.LblReplace1.TabIndex = 0;
            this.LblReplace1.Text = "替 换：";
            // 
            // LblReplace2
            // 
            this.LblReplace2.AutoSize = true;
            this.LblReplace2.Location = new System.Drawing.Point(13, 48);
            this.LblReplace2.Name = "LblReplace2";
            this.LblReplace2.Size = new System.Drawing.Size(67, 15);
            this.LblReplace2.TabIndex = 1;
            this.LblReplace2.Text = "替换为：";
            // 
            // TxtBoxReplace1
            // 
            this.TxtBoxReplace1.Location = new System.Drawing.Point(79, 10);
            this.TxtBoxReplace1.Name = "TxtBoxReplace1";
            this.TxtBoxReplace1.Size = new System.Drawing.Size(269, 25);
            this.TxtBoxReplace1.TabIndex = 2;
            // 
            // TxtBoxReplace2
            // 
            this.TxtBoxReplace2.Location = new System.Drawing.Point(79, 45);
            this.TxtBoxReplace2.Name = "TxtBoxReplace2";
            this.TxtBoxReplace2.Size = new System.Drawing.Size(269, 25);
            this.TxtBoxReplace2.TabIndex = 3;
            // 
            // BtnCancel
            // 
            this.BtnCancel.Location = new System.Drawing.Point(214, 81);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.Size = new System.Drawing.Size(80, 35);
            this.BtnCancel.TabIndex = 5;
            this.BtnCancel.Text = "取消";
            this.BtnCancel.UseVisualStyleBackColor = true;
            this.BtnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(66, 81);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(80, 35);
            this.button1.TabIndex = 6;
            this.button1.Text = "替换所有";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Replace
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(360, 130);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.BtnCancel);
            this.Controls.Add(this.TxtBoxReplace2);
            this.Controls.Add(this.TxtBoxReplace1);
            this.Controls.Add(this.LblReplace2);
            this.Controls.Add(this.LblReplace1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Replace";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Replace";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblReplace1;
        private System.Windows.Forms.Label LblReplace2;
        private System.Windows.Forms.TextBox TxtBoxReplace1;
        private System.Windows.Forms.TextBox TxtBoxReplace2;
        private System.Windows.Forms.Button BtnCancel;
        private System.Windows.Forms.Button button1;
    }
}