﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Editor
{
    public partial class Find : Form
    {
        public Find()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 单机取消退出此窗体
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// 在TxtBox中查找是否存在TxtFind中的子串
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnFind_Click(object sender, EventArgs e)
        {
            try
            {
                //判断是否包含有目标子串
                if (TextFind._RTxtBox.Text.Contains(TxtFind.Text))
                {
                    //找出目标子串在母串出现的所有位置，//把目标子串变成红色
                    int index = TextFind._RTxtBox.Text.IndexOf(TxtFind.Text);
                    do
                    {
                        TextFind._RTxtBox.Select(index, TxtFind.Text.Length);
                        TextFind._RTxtBox.SelectionColor = Color.Red;
                        index = TextFind._RTxtBox.Text.IndexOf(TxtFind.Text, index + 1);
                    } while (TextFind._RTxtBox.Text.LastIndexOf(TxtFind.Text) != index);
                    TextFind._RTxtBox.Select(index, TxtFind.Text.Length);
                    TextFind._RTxtBox.SelectionColor = Color.Red;

                    //把光标移至第一个关键词的位置
                    TextFind._RTxtBox.Select(TextFind._RTxtBox.Text.IndexOf(TxtFind.Text), TxtFind.Text.Length);
                    this.Close();
                }
                else
                {
                    //如果没找到则显示提示
                    MessageBox.Show("未找到" + TxtFind.Text);
                    TxtFind.Clear();
                }
            }
            catch { }
        }
    }
}
